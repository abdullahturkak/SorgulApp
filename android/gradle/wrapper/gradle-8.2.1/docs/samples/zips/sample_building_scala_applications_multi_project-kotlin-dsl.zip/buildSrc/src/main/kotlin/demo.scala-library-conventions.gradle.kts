
plugins {
    id("demo.scala-common-conventions") // <1>

    `java-library` // <2>
}
