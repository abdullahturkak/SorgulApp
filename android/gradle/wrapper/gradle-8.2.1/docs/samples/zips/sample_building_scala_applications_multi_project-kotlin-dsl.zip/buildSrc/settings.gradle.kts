
rootProject.name = "buildSrc"
