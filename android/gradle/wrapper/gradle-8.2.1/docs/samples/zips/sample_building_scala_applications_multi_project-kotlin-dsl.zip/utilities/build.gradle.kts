
plugins {
    id("demo.scala-library-conventions")
}

dependencies {
    api(project(":list"))
}
