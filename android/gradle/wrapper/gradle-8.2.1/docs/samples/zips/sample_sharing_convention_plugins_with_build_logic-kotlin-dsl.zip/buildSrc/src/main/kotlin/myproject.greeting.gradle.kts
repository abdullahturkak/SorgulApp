tasks.register<com.example.GreetingTask>("greet") {
    greeting.set("Hello from 'myproject.greeting' plugin")
}
