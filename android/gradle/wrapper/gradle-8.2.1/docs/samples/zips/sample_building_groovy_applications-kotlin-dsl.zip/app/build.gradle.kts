
plugins {
    groovy // <1>

    application // <2>
}

repositories {
    mavenCentral() // <3>
}

dependencies {
    implementation("org.codehaus.groovy:groovy-all:3.0.15") // <4>

    implementation("com.google.guava:guava:31.1-jre") // <5>

    testImplementation("org.spockframework:spock-core:2.2-groovy-3.0") // <6>
    testImplementation("junit:junit:4.13.2")

    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

application {
    mainClass.set("demo.App") // <7>
}

tasks.named<Test>("test") {
    useJUnitPlatform() // <8>
}
