
plugins {
    id("demo.java-library-conventions")
}
