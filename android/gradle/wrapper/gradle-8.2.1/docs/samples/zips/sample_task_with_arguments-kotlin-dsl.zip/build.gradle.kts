plugins {
    id("com.example.project-info")
}

version = "1.0.2"
