rootProject.name = "modules-multi-project"
include("application", "list", "utilities")
