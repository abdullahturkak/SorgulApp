module org.gradle.sample.app {
    exports org.gradle.sample.app;
    requires org.gradle.sample.utilities;
}
