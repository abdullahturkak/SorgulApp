rootProject.name = "modules-multi-project-with-integration-tests"
include("application", "list", "utilities")
