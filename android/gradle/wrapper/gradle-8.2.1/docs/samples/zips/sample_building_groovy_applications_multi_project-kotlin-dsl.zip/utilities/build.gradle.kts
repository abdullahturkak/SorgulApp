
plugins {
    id("demo.groovy-library-conventions")
}

dependencies {
    api(project(":list"))
}
