rootProject.name = "my-app"

include("app")
