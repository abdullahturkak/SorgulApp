package com.example.myproduct.model

data class MyProductReleaseList(val releases: List<MyProductRelease>)
