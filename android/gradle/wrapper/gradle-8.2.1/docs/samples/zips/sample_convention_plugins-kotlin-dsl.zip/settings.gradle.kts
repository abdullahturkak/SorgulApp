rootProject.name = "sample"
include("internal-module", "library-a", "library-b")
